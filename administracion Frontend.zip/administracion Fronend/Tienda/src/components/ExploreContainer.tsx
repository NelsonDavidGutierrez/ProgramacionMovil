// src/pages/AddPatient.tsx (modified)

import { IonButton, IonContent, IonHeader, IonInput, IonPage, IonTitle, IonToolbar } from '@ionic/react';
import React, { useState } from 'react';
import { useHistory } from 'react-router';

const Addcliente: React.FC = () => {
  const [productName, setProductName] = useState<string>(''); // Renamed to productName
  const [productPrice, setProductPrice] = useState<string>(''); // Renamed to productPrice
  const [productCategory, setProductCategory] = useState<string>('');

  const history = useHistory();

  const Addcliente = () => {
    // Here, you can add logic to save the product data
    // For example, sending data to a server or local storage
    console.log('Product Name:', productName);
    console.log('Product Price:', productPrice);
    console.log('Product Category:', productCategory);

    // You can add further logic here, like navigating or clearing fields
    history.push('/Cliente-list'); // Replace with appropriate path
  };

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Add Product</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent>
        <IonInput placeholder="Product Name" value={productName} onIonChange={(e) => setProductName(e.detail.value!)} />
        <IonInput placeholder="Price" value={productPrice} onIonChange={(e) => setProductPrice(e.detail.value!)} />
        <IonInput placeholder="Category" value={productCategory} onIonChange={(e) => setProductCategory(e.detail.value!)} />
        <IonButton onClick={Addcliente}>Save Product</IonButton>
      </IonContent>
    </IonPage>
  );
};

export default Addcliente;
