// src/pages/AddPatient.tsx (modified)

import { IonButton, IonContent, IonHeader, IonInput, IonPage, IonTitle, IonToolbar } from '@ionic/react';
import React, { useState } from 'react';
import { useHistory } from 'react-router';

const addCategoria: React.FC = () => {
  const [categoryName, setCategoryName] = useState<string>(''); // Renamed to categoryName
  const [categoryDescription, setCategoryDescription] = useState<string>('');

  const history = useHistory();

  const addCategoria = () => {
    // Here, you can add logic to save the category data
    // For example, sending data to a server or local storage
    console.log('Category Name:', categoryName);
    console.log('Category Description:', categoryDescription);

    // You can add further logic here, like navigating or clearing fields
    history.push('/categoria-list'); // Replace with appropriate path
  };

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Add Category</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent>
        <IonInput placeholder="Category Name" value={categoryName} onIonChange={(e) => setCategoryName(e.detail.value!)} />
        <IonInput placeholder="Category Description" value={categoryDescription} onIonChange={(e) => setCategoryDescription(e.detail.value!)} />
        <IonButton onClick={addCategoria}>Save Category</IonButton>
      </IonContent>
    </IonPage>
  );
};

export default addCategoria;
