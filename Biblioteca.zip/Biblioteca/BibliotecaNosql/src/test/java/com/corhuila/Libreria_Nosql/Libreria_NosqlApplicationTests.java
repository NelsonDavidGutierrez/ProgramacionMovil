package com.corhuila.Libreria_Nosql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Libreria_NosqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
