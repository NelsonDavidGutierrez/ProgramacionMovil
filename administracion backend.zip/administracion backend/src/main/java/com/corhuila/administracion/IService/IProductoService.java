package com.corhuila.administracion.IService;

import com.corhuila.administracion.Entity.Producto;

import java.util.List;
import java.util.Optional;

public interface IProductoService {
    List<Producto> findAll(); // Devuelve una lista de facturas
    Optional<Producto> findById(Long id); // Devuelve un factura por su id
    Producto save(Producto autor); // Guarda un autor
    void update(Producto producto, Long id); // Actualiza un autor
    void delete(Long id); // Elimina un factura
}
