package com.corhuila.administracion.IService;

import com.corhuila.administracion.Entity.Categoria;

import java.util.List;
import java.util.Optional;

public interface ICategoriaService {
    List<Categoria> findAll(); // Devuelve una lista de clientes
    Optional<Categoria> findById(Long id); // Devuelve un cliente por su id
    Categoria save(Categoria categoria); // Guarda un libro
    void update(Categoria categoria, Long id); // Actualiza un libro

}
