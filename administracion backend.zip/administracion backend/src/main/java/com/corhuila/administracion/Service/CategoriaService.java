package com.corhuila.administracion.Service;

import com.corhuila.administracion.Entity.Categoria;
import com.corhuila.administracion.IRepository.ICategoriaRepository;
import com.corhuila.administracion.IService.ICategoriaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CategoriaService implements ICategoriaService {

    //Conectar con los datos - IRepository
    // Inyección de dependencia
    @Autowired
    private ICategoriaRepository repository;


    @Override
    public List<Categoria> findAll() {
       return repository.findAll();
    }

    @Override
    public Optional<Categoria> findById(Long id) {
        return repository.findById(id);
    }

    @Override
    public Categoria save(Categoria categoria) {
        return repository.save(categoria);
    }

    @Override
    public void update(Categoria categoria, Long id) {
        //Obtener el objeto libro y el id
        //Verificar con el id, si exiten los datos
        Optional<Categoria> ps = repository.findById(id);

        //Cargar nuevo objeto
        if (!ps.isEmpty()){
            Categoria categoriaUpdate = ps.get();
            categoriaUpdate.setNombre(categoria.getNombre());
            categoriaUpdate.setDescripcion(categoria.getDescripcion());

            //Actualizar el objeto libro
            repository.save(categoriaUpdate);
        }else{
            System.out.println("No existe el libro");
        }
    }


}
