package com.corhuila.administracion.Service;

import com.corhuila.administracion.Entity.Producto;
import com.corhuila.administracion.IRepository.IProductoRepository;
import com.corhuila.administracion.IService.IProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductoService implements IProductoService {

    //Conectar con los datos - IRepository
    // Inyección de dependencia
    @Autowired
    private IProductoRepository repository;


    @Override
    public List<Producto> findAll() {
       return repository.findAll();
    }

    @Override
    public Optional<Producto> findById(Long id) {
        return repository.findById(id);
    }

    @Override
    public Producto save(Producto autor) {
        return repository.save(autor);
    }

    @Override
    public void update(Producto producto, Long id) {
        //Obtener el objeto autor y el id
        //Verificar con el id, si exiten los datos
        Optional<Producto> ps = repository.findById(id);

        //Cargar nuevo objeto
        if (!ps.isEmpty()){
            Producto productoUpdate = ps.get();
            productoUpdate.setNombre(producto.getNombre());
            productoUpdate.setPrecio(producto.getPrecio());

            //Actualizar el objeto autor
            repository.save(productoUpdate);
        }else{
            System.out.println("No existe el autor");
        }
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }
}
