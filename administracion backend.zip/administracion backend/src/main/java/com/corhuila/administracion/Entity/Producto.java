package com.corhuila.administracion.Entity;

import jakarta.persistence.*;
import lombok.Data;

import java.util.Date;
@Data
@Entity
@Table(name = "producto")
public class Producto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String Nombre;
    private int Precio ;

    @ManyToOne
    @JoinColumn(name = "categoria_id") // Nombre de la columna que será clave foránea
    private Categoria categoria;

}
